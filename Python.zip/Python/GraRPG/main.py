import pygame
import random
import button
import csv

pygame.init()
#dodawanie muzyczki
pygame.mixer.init()

clock = pygame.time.Clock()
fps = 60


pygame.mixer.music.load('GraRPG/Background_Music.mp3')  # Replace with your music file path
pygame.mixer.music.set_volume(0.05)  # Set volume (0.0 to 1.0)
pygame.mixer.music.play(-1)

#Okno gry
bottom_panel = 200
screen_width = 1280
screen_height = 720 + bottom_panel

screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption('battle')


current_fighter = 1
total_fighters = 2
action_cooldown = 0
action_wait_time = 90
attack = False
clicked = False
game_over = 0



#kolory i font
font = pygame.font.SysFont('Times New Roman', 26)
red = (255,0,0)
green = (0,255,0)
yellow = (255, 255, 0)


BOSS_RESPONSE_PRZEDSTAW_SIE = pygame.USEREVENT + 1
BOSS_RESPONSE_ROZMAWIAJ = pygame.USEREVENT + 2

#backgroun & panel
background_img = pygame.image.load('GraRPG/img/Background/0.png').convert_alpha()
panel_img = pygame.image.load('GraRPG/img/Panel/Panel.png').convert_alpha()
#Button images
attack_img = pygame.image.load('GraRPG/img/icons/attack_button.png').convert_alpha()
run_img = pygame.image.load('GraRPG/img/icons/run_button.png').convert_alpha()
przedstaw_sie_img = pygame.image.load('GraRPG/img/icons/przedstaw_sie.png').convert_alpha()
rozmawiaj_img = pygame.image.load('GraRPG/img/icons/rozmawiaj.png').convert_alpha()
restart_img = pygame.image.load('GraRPG/img/icons/restart.png').convert_alpha()

#IMAGES
victory_img = pygame.image.load('GraRPG/img/icons/victory.png').convert_alpha()
defeat_img = pygame.image.load('GraRPG/img/icons/defeat.png').convert_alpha()




# Rejestracja
def register_user(username, password):
    with open('users.csv', 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([username, password])  # Store password as plain text

# Czy uzytkownik istnieje
def username_exists(username):
    with open('users.csv', 'r') as file:
        reader = csv.reader(file)
        for row in reader:
            if row[0] == username:
                return True
    return False

# user validation
def validate_login(username, password):
    with open('users.csv', 'r') as file:
        reader = csv.reader(file)
        for row in reader:
            if row[0] == username and row[1] == password:
                return True
    return False

# Rejestracja uzytkownika
def user_authentication():
    while True:
        user = input("Enter username: ")
        pwd = input("Enter password: ")

        if validate_login(user, pwd):
            print("Logged in successfully!")
            return True
        else:
            if not username_exists(user):
                print("Username does not exist.")
                choice = input("Do you want to create a new account with this username? (yes/no): ")
                if choice.lower() == 'yes':
                    register_user(user, pwd)
                    print("User registered successfully!")
                    return True
                elif choice.lower() == 'no':
                    print("Account creation cancelled.")
                    continue  # Will prompt for username and password again
                else:
                    print("Invalid input. Please enter 'yes' or 'no'.")
            else:
                print("Invalid password. Please try again.")
    return False  # In case of exit from loop

#Text
def draw_text(text,font,text_col,x,y):
    img = font.render(text,True,text_col)
    screen.blit(img,(x,y))


#Tlo
def draw_bg():
    screen.blit(background_img, (0, 0))

#Panel dolny
def draw_panel():
    screen.blit(panel_img, (0, screen_height - bottom_panel))
    #HP 
    draw_text(f'{player.name} HP:{player.hp}',font,red,300,screen_height- bottom_panel + 40)
    draw_text(f'{current_boss.name} HP:{current_boss.hp}',font,red,800,screen_height- bottom_panel + 40)






#Klasa bohatera
class Fighter():
    def __init__(self, x, y, name, max_hp, strength, dexterity, intelligence, fighter_type):
        self.name = name
        self.max_hp = max_hp
        self.hp = max_hp
        self.strength = strength
        self.dexterity = dexterity
        self.intelligence = intelligence
        self.fighter_type = fighter_type  # New attribute
        self.alive = True
        img = pygame.image.load(f'GraRPG/img/hero/{self.name}/0.png')
        self.image = pygame.transform.scale(img,(img.get_width()*1, img.get_height()*1))
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)

    def reset(self):
        self.hp = self.max_hp
        self.alive = True
        self.action = 0

    def attack(self, target):
        # Metoda ataku zależna od postaci
        rand = random.randint(-5, 5)
        evasion_chance = min(target.dexterity, 50)  # dexterity * 2 to convert to percentage, max 50%
        if self.fighter_type == 'knight':
            damage = self.strength + rand +self.dexterity * 0.5
        elif self.fighter_type == 'mage':
            damage = self.intelligence*1.5 + rand
        elif self.fighter_type == 'thief':
            damage = self.dexterity + rand
        elif self.fighter_type == 'barbarian':
            damage = self.strength + rand  
        else:
            damage = self.strength + rand 
            #mechanika evade'a
        if random.randint(1, 100) <= evasion_chance:
            damage = 0 
            damage_text = DamageText(target.rect.centerx, target.rect.y, "Miss!", green)
        else:
            target.hp -= damage
        #if dead
            if target.hp <1:
                target.hp = 0
                target.alive = False 
            damage_text = DamageText(target.rect.centerx,target.rect.y,str(damage),red)

        damage_text_group.add(damage_text)


        

    def draw(self):
        screen.blit(self.image, self.rect)

#paski zycia
class HealthBar():
    def __init__(self, x, y, hp, max_hp):
        self.x = x
        self.y = y
        self.hp = hp
        self.max_hp = max_hp  # Correct this line

    def draw(self, hp):
        #hp nie przewyzsza maksymalnego
        self.hp = min(hp, self.max_hp)
        #obliczanie hp
        ratio = self.hp / self.max_hp
        pygame.draw.rect(screen, red, (self.x, self.y, 150, 20))  # Background health bar
        pygame.draw.rect(screen, green, (self.x, self.y, 150 * ratio, 20))  # Foreground health bar

class DamageText(pygame.sprite.Sprite):
    def __init__(self, x, y, damage, colour):
        pygame.sprite.Sprite.__init__(self)
        self.image = font.render(damage, True, colour)
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.counter = 0

    def update(self):
        self.rect.y -= 1 
        self.counter += 1
        if self.counter > 40:  
            self.kill()
class GenericText(pygame.sprite.Sprite):
    def __init__(self, x, y, text, color, font):
        pygame.sprite.Sprite.__init__(self)
        self.image = font.render(text, True, color)
        self.rect = self.image.get_rect()
        self.rect.center = (x, y)
        self.counter = 0

    def update(self):
        self.rect.y -= 0.5 
        self.counter += 1
        if self.counter > 80:
            self.kill()  

# wielkosc przyciskow
button_width, button_height = 150, 200
horizontal_spacing = 100
vertical_spacing = 20

# pozycja rzedu i kolumn
row1_y = screen_height // 2 - button_height - vertical_spacing // 2
row2_y = screen_height // 2 + vertical_spacing // 2
column1_x = screen_width // 2 - button_width - horizontal_spacing // 2
column2_x = screen_width // 2 + horizontal_spacing // 2


    # skalowanie img klass
knight_img = pygame.transform.scale(pygame.image.load('GraRPG/img/hero/knight/0.png').convert_alpha(), (button_width, button_height))
mage_img = pygame.transform.scale(pygame.image.load('GraRPG/img/hero/Mage/0.png').convert_alpha(), (button_width, button_height))
thief_img = pygame.transform.scale(pygame.image.load('GraRPG/img/hero/thief/0.png').convert_alpha(), (button_width, button_height))
barbarian_img = pygame.transform.scale(pygame.image.load('GraRPG/img/hero/barbarian/0.png').convert_alpha(), (button_width, button_height))


knight_button = button.Button(screen, column1_x, row1_y, knight_img, button_width, button_height)
mage_button = button.Button(screen, column2_x, row1_y, mage_img, button_width, button_height)
thief_button = button.Button(screen, column1_x, row2_y, thief_img, button_width, button_height)
barbarian_button = button.Button(screen, column2_x, row2_y, barbarian_img, button_width, button_height)
#selekcja klasy
def class_selection_menu(screen, font):
    running = True
    while running:
        screen.fill((0, 0, 0))  # Clear the screen

        # wywolanie przyciskow i tekstu
        if knight_button.draw():
            return 'knight'
        if mage_button.draw():
            return 'mage'
        if thief_button.draw():
            return 'thief'
        if barbarian_button.draw():
            return 'barbarian'

        draw_text("Knight", font, red, knight_button.rect.centerx, knight_button.rect.bottom + 10)
        draw_text("Mage", font, red, mage_button.rect.centerx, mage_button.rect.bottom + 10)
        draw_text("Thief", font, red, thief_button.rect.centerx, thief_button.rect.bottom + 10)
        draw_text("Barbarian", font, red, barbarian_button.rect.centerx, barbarian_button.rect.bottom + 10)


        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()

        pygame.display.update()


damage_text_group = pygame.sprite.Group()


#pozycjonowanie przyciskow
attack_button = button.Button(screen,300,screen_height- bottom_panel + 100,attack_img,32,32)
back_button = button.Button(screen, 400, screen_height - bottom_panel + 100, run_img, 32, 32)  
rozmawiaj_button = button.Button(screen, 500, screen_height - bottom_panel + 100, przedstaw_sie_img, 32, 32)
przedstaw_sie_button = button.Button(screen, 630, screen_height - bottom_panel + 100, rozmawiaj_img, 32, 32)
restart_button = button.Button(screen, screen_width // 2 - 60, screen_height // 2 + 100, restart_img, 120, 40)

#stat selection
def stat_selection_menu(screen, font, player):
    running = True
    while running:
        screen.fill((0, 0, 0))  # Clear the screen

        
        draw_text("Increase Strength (S)", font, red, 100, screen_height // 2 - 30)
        draw_text("Increase Dexterity (D)", font, red, 100, screen_height // 2)
        draw_text("Increase Intelligence (I)", font, red, 100, screen_height // 2 + 30)

        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_s:
                    player.strength += 5  # Increase strength
                    running = False
                elif event.key == pygame.K_d:
                    player.dexterity += 5  # Increase dexterity
                    running = False
                elif event.key == pygame.K_i:
                    player.intelligence += 5  # Increase intelligence
                    running = False
            elif event.type == pygame.QUIT:
                pygame.quit()
                exit()

        pygame.display.update()

#wybor klasy
selected_class = class_selection_menu(screen, font)
if selected_class == 'knight':
    player = Fighter(350, 475, 'Knight', 50, 25, 10, 5, 'knight')
elif selected_class == 'mage':
    player = Fighter(350, 475, 'Mage', 30, 10, 5, 25, 'mage')
elif selected_class == 'thief':
    player = Fighter(350, 475, 'Thief', 40, 10, 20, 10, 'thief')
elif selected_class == 'barbarian':
    player = Fighter(350, 475, 'Barbarian', 60, 20, 5, 1, 'barbarian')
else:
    pygame.quit()
    exit()

#bossy
boss = Fighter(850, 440, 'Fallen Arch Mage', 150, 20, 10, 5, 'boss')  # Example boss
second_boss = Fighter(850, 440, 'Green Ogre', 170, 25, 15, 10, 'boss')  # Example second boss with different stats
third_boss = Fighter(850, 440, 'Phantom Ghost', 250, 35, 15, 15, 'boss')  # Example second boss with different stats



current_boss = boss
boss_stage = 1

player_healt_bar = HealthBar(300, screen_height - bottom_panel + 70, player.hp, player.max_hp)
boss_healt_bar = HealthBar(800, screen_height - bottom_panel + 70, boss.hp, boss.max_hp)

#Main Game Loop
user_logged_in = user_authentication()  # Call the authentication function
if user_logged_in:
    run = True
    in_class_selection = True
    while run:
        clock.tick(fps)

        if in_class_selection:
            selected_class = class_selection_menu(screen, font)
            # Wywolywanie klasy
            if selected_class == 'knight':
                player = Fighter(350, 475, 'Knight', 70, 35, 5, 5, 'knight')
            elif selected_class == 'mage':
                player = Fighter(350, 475, 'Mage', 50, 10, 5, 45, 'mage')
            elif selected_class == 'thief':
                    player = Fighter(350, 475, 'Thief', 40, 10, 30, 10, 'thief')
            elif selected_class == 'barbarian':
                player = Fighter(350, 475, 'Barbarian', 80, 20, 15, 1, 'barbarian')


            player_healt_bar = HealthBar(300, screen_height - bottom_panel + 70, player.hp, player.max_hp)
            in_class_selection = False




        
        draw_bg()
        draw_panel()

        player_healt_bar.draw(player.hp)
        boss_healt_bar.draw(boss.hp)

        player.draw()

        damage_text_group.update()
        damage_text_group.draw(screen)

        # wywolanie aktualnego bossa
        current_boss.draw()
        current_boss_health_bar = HealthBar(800, screen_height - bottom_panel + 70, current_boss.hp, current_boss.max_hp)
        current_boss_health_bar.draw(current_boss.hp)

            #sprawdzanie etapu gry   
        if game_over != 0:
            if game_over == 1:  #gracz umarl
                stat_selection_menu(screen, font, player)
                player.reset()
                current_boss.reset()
                current_fighter = 1
                action_cooldown = 0
                game_over = 0
                damage_text_group.empty()
            elif game_over == -1:  # boss pokonany
                if boss_stage == 1:
                    # przejscie do 2 bossa
                    boss_stage += 1
                    current_boss = second_boss
                    current_boss_health_bar = HealthBar(800, screen_height - bottom_panel + 70, current_boss.hp, current_boss.max_hp)
                    # reset
                    player.reset()
                    current_boss.reset()
                    current_fighter = 1
                    action_cooldown = 0
                    game_over = 0
                    damage_text_group.empty()
                elif boss_stage == 2:
                    # do 3 bossa
                    boss_stage += 1
                    current_boss = third_boss
                    current_boss_health_bar = HealthBar(800, screen_height - bottom_panel + 70, current_boss.hp, current_boss.max_hp)
                    # Reset
                    player.reset()
                    current_boss.reset()
                    current_fighter = 1
                    action_cooldown = 0
                    game_over = 0
                    damage_text_group.empty()
                else:
                    # victory img po wygraniu
                    screen.blit(victory_img, (screen_width // 2 - victory_img.get_width() // 2, screen_height // 2 - victory_img.get_height() //1 ))
                    if restart_button.draw():
                    # Reset button po koncu gry
                        player.reset()
                        boss.reset()
                        second_boss.reset()
                        third_boss.reset()
                        current_boss = boss
                        boss_stage = 1
                        current_fighter = 1
                        action_cooldown = 0
                        game_over = 0
                        damage_text_group.empty()
                        in_class_selection = True
        #akcja
        attack = False
        target = None
        pos = pygame.mouse.get_pos()
        
        #funkcje przyciskow
        if attack_button.draw():
            attack = True
            target = current_boss

        if przedstaw_sie_button.draw():
            message_text = GenericText(player.rect.centerx, player.rect.y - 50, "Nazywam się{username}", yellow, font)
            damage_text_group.add(message_text)
            pygame.time.set_timer(BOSS_RESPONSE_PRZEDSTAW_SIE, 1000)  # Set timer for 1 second

        if rozmawiaj_button.draw():
            message_text = GenericText(player.rect.centerx, player.rect.y - 50, "Rozmawiam...", yellow, font)
            damage_text_group.add(message_text)
            pygame.time.set_timer(BOSS_RESPONSE_ROZMAWIAJ, 1000)  # Set timer for 1 second

        #nazwa przyciskow
        attack_button_text_position = (attack_button.rect.x, attack_button.rect.y + attack_button.rect.height + 10)
        back_button_text_position = (back_button.rect.x, back_button.rect.y + back_button.rect.height + 10)
        rozmawiaj_button_text_position = (rozmawiaj_button.rect.x, rozmawiaj_button.rect.y + rozmawiaj_button.rect.height + 10)
        przedstaw_sie_button_text_position = (przedstaw_sie_button.rect.x, przedstaw_sie_button.rect.y + przedstaw_sie_button.rect.height + 10)
    
        draw_text("Atakuj", font, red, *attack_button_text_position)
        draw_text("Uciekaj", font, red, *back_button_text_position)
        draw_text("Rozmawiaj", font, red, *rozmawiaj_button_text_position)
        draw_text("Przedstaw Się", font, red, *przedstaw_sie_button_text_position)



        #Tura gracza
        if current_fighter == 1:
            action_cooldown += 1
            if action_cooldown >= action_wait_time and player.alive:
                if attack == True and target != None:
                    player.attack(target)
                    current_fighter = 2
                    action_cooldown = 0
                    if current_boss.hp <= 0:
                        current_boss.hp = 0
                        current_boss.alive = False
                        game_over = -1 

        #Tura bossa
        elif current_fighter == 2:
            action_cooldown += 1
            if action_cooldown >= action_wait_time and current_boss.alive:
                current_boss.attack(player)
                current_fighter = 1
                action_cooldown = 0
                if player.hp <= 0:
                    player.hp = 0
                    player.alive = False
                    game_over = 1  



        #Wywolanie przycisku run
        if back_button.draw():
            in_class_selection = True
            boss.reset() 
            player.reset() 
            current_fighter = 1  
            action_cooldown = 0 
            boss_stage = 1  
            current_boss = boss
            damage_text_group.empty()



        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                clicked = True
            else: 
                clicked = False
            
            # eventy
            if event.type == BOSS_RESPONSE_PRZEDSTAW_SIE:
                response_text = GenericText(current_boss.rect.centerx, current_boss.rect.y - 50, "I don't care", yellow, font)
                damage_text_group.add(response_text)
                pygame.time.set_timer(BOSS_RESPONSE_PRZEDSTAW_SIE, 0) 

            if event.type == BOSS_RESPONSE_ROZMAWIAJ:
                response_text = GenericText(current_boss.rect.centerx, current_boss.rect.y - 50, "fight me noob", yellow, font)
                damage_text_group.add(response_text)
                pygame.time.set_timer(BOSS_RESPONSE_ROZMAWIAJ, 0)  

        pygame.display.update()

    pygame.quit()

else:
    print("Authentication failed. Exiting game.")
    pygame.quit()