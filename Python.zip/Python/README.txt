Gra stworzona za pomocą biblioteki Pygame więc:
pip install pygame
oraz pip install csv (jesli nie jest podstawowo)


Jest to gra turowa na zasadzie Souls-like. Nie da się w niej przegrać - po przegranej walce z jednym z bossow
wyświetla się okienko w którym można wybrać jedną z 3 statystyk - Strength (klawisz S) Dexterity (Klawisz D)
i Intelligence (Klawisz I) Każda z 4 klas postaci posiada osobne statystyki oraz skalowanie DMG. 

Dla Knighta jest to Wartośc siły + random(-5,5) oraz 0*5 zreczności
Dla Maga jest to Inteligencja *1.5 + random
Dla Thiefa jest to Dex + random
Dla Barbariana jest to Str+random

Dodatkowo jest w tej grze mechanika obronna (Evasion) która skaluje się z Dexem:

Za każdy punkt w dexterity na postaci dostaje sie 2% evasion. Przy czym maksymalna wartość evade'a wynosi 50%
czyli mając 25 dexterity ma się 50% evasion chance więc 1/2 ataki powinny zostać uniknięte.

Gra obsługuje też funkcję użytkowników - po odpaleniu gry i zaznaczeniu jednej z klas nie przeniesie
nas od razu do rozgrywki, tylko trzeba zarejestrować użytkownia/zalogować się w terminalu Python

Dane przechowywane są w pliku users.csv


--dalsze plany rozwoju---

Dodanie animacji postaci (obecne postacie były tworzone za pomocą programów graficznych AI) 
Animacja będzie działać na zasadzie wczytywania się po kolei obrazków (0.png,1.png,2.png...)

-Dodanie logowania w oknie gry
- %szansy na kryta
- Urozmaicenie walki: np dodatkowy skill defensywny(zabierający jedną ture)
- dodanie Potionów
- Dodanie poziomów między bossami, czyli np walka z 3 słabszymi przeciwnikami
- Cokolwiek mi jeszcze wpadnie do głowy